//
//  SpeexKit.h
//  SpeexKit
//
//  Created by zhihui liang on 2018/8/20.
//  Copyright © 2018年 www.zh-jieli.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SpeexKit.
FOUNDATION_EXPORT double SpeexKitVersionNumber;

//! Project version string for SpeexKit.
FOUNDATION_EXPORT const unsigned char SpeexKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SpeexKit/PublicHeader.h>

#import <SpeexKit/SpeexUnit.h>
#import <SpeexKit/OpusUnit.h>
