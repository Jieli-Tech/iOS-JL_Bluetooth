//
//  MusicVC.h
//  QCY_Demo
//
//  Created by JL_HoPe on 2021/1/8.
//  Copyright © 2021 杰理科技. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MusicVC : UIViewController

@end

NS_ASSUME_NONNULL_END
