//
//  TwoVC.m
//  QCY_Demo
//
//  Created by 杰理科技 on 2020/3/17.
//  Copyright © 2020 杰理科技. All rights reserved.
//

#import "TwoVC.h"

@interface TwoVC (){

}

@end

@implementation TwoVC

- (void)viewDidLoad {
    [super viewDidLoad];

}

-(void)setupUI{
    float sW = [DFUITools screen_2_W];
    float sH = [DFUITools screen_2_H];
}






@end
